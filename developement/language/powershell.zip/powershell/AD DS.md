Editions qui ne peuvent pas rejoinder un domaine : 

- Windows 11 Home 
    
- Windows 10 Home 
    
- Windows 8/8.1 Core (Home) 
    
- Windows 7 Home Premium / Basic 
    

Windows Famille est la version française de Windows Home


trés lié a :
[[DHCP]]
[[DNS]]


controle de VM
[[DEPLOY]]
[[DESTROY]]
[[START]]
[[STOP]]

[[installation rôle]]
[[script ajout sous domaine]]
[[creation agdlp]]



envoi configuration PC et utilisateur via
[[GPO]]