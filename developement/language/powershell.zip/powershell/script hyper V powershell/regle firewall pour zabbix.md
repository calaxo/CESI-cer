




192.168.20.15


netsh advfirewall firewall add rule name="Open Zabbix agentd port 165 inbound" dir=in action=allow protocol=UDP remoteip=192.168.20.15 localport=161

loqique phyisqiue adminsiration