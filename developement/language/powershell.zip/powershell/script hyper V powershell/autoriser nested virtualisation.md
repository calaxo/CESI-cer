
Set-VMProcessor -VMName "Windows-10" -ExposeVirtualizationExtensions $true







