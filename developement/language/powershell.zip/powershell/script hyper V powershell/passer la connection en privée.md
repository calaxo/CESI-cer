pour trouver interfacealias

 Get-NetConnectionProfile

Set-NetConnectionProfile -InterfaceAlias "Ethernet 2" -NetworkCategory Private


