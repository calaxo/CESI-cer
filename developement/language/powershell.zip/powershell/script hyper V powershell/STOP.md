``` powershell
$vm_home = 'F:\vmdev'
$vm_name = 'DevHyperV'
$my_VHD='hd20GB.vhdx'
$my_iso="F:\vmdevubuntu.iso"


Stop-VM -name $vm_name -Force



```
